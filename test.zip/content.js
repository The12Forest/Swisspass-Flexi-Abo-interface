/**
 * Content script — runs in MAIN world on swisspass.ch
 * Patches window.fetch to intercept OAuth token responses
 * and sends them to the background service worker.
 */
(function () {
    const originalFetch = window.fetch;

    window.fetch = async function (...args) {
        const response = await originalFetch.apply(this, args);

        try {
            const url = typeof args[0] === 'string' ? args[0] : args[0]?.url;
            if (url && url.includes('/oauth2/') && url.includes('/token')) {
                // Clone the response so we can read it without consuming it
                const clone = response.clone();
                clone.json().then(data => {
                    if (data.refresh_token) {
                        window.postMessage({
                            type: 'SWISSPASS_TOKEN_CAPTURED',
                            refreshToken: data.refresh_token,
                            accessToken: data.access_token,
                        }, '*');
                    }
                }).catch(() => {});
            }
        } catch {}

        return response;
    };

    // Listen for messages from background script
    window.addEventListener('message', e => {
        if (e.source !== window) return;
        if (e.data?.type === 'SWISSPASS_TOKEN_CAPTURED') {
            chrome.runtime.sendMessage({
                type: 'TOKEN_CAPTURED',
                refreshToken: e.data.refreshToken,
            });
        }
    });
})();
